# PyTodo

This is a little todolist utility i made in python. This was a hobby project that i started to get comfortable with working in git and using uv. If you want you can totally download this and you can submit PRs. Just remember the chances of me even seeing you PR let alone addressing it are very low. 



  **note**: I will try to give some download instruction shortly. For now if you want to try and download it from source code good luck.